
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(335, 276)
        self.frame = QtWidgets.QFrame(Dialog)
        self.frame.setGeometry(QtCore.QRect(60, 60, 211, 201))
        self.frame.setFrameShape(QtWidgets.QFrame.Panel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.paid = QtWidgets.QRadioButton(self.frame)
        self.paid.setGeometry(QtCore.QRect(20, 30, 231, 41))
        self.paid.setAutoFillBackground(False)
        self.paid.setObjectName("paid")
        self.notpaid = QtWidgets.QRadioButton(self.frame)
        self.notpaid.setGeometry(QtCore.QRect(20, 60, 131, 71))
        self.notpaid.setObjectName("notpaid")
        self.submit = QtWidgets.QPushButton(self.frame)
        self.submit.setGeometry(QtCore.QRect(100, 140, 101, 41))
        self.submit.setObjectName("submit")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 0, 371, 71))
        self.label.setObjectName("label")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Server Side"))
        self.paid.setText(_translate("Dialog", "Paid"))
        self.notpaid.setText(_translate("Dialog", "Not Paid"))
        self.submit.setText(_translate("Dialog", "Submit"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:7pt;\">This Process Will Happens On server Side</span></p></body></html>"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
