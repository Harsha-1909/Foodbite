import sqlite3
import pandas as pd


class Register:
    def __init__(self,db):
        self.conn=sqlite3.connect(db)
        self.cur=self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS LOG(orderid Text,pay_status Text,misalpav Text,idlysambhar Text,sambharvada Text,pavbhaji Text,breadomlet Text,teabiscut Text,poori Text,review Text,review_sta Text)")
        self.conn.commit()

    def add(self,orderid,pay_status,misalpav,idlysambhar,sambharvada,pavbhaji,breadomlet,teabiscut,poori,review,review_sta):
        self.cur.execute("INSERT INTO LOG VALUES (?,?,?,?,?,?,?,?,?,?,?)",(orderid,pay_status,misalpav,idlysambhar,sambharvada,pavbhaji,breadomlet,teabiscut,poori,review,review_sta,))
        self.conn.commit()
        print("Your Food Items Are Ordered :)")


    def order_search(self,orderid):
        row=self.cur.execute("SELECT * FROM LOG WHERE orderid=?",(orderid,)).fetchall()
        if not row:
            return False
        else:
            return row

    def update_pay_status(self,orderid,pay_status):
        self.cur.execute("UPDATE LOG SET pay_status=? WHERE orderid=?",(pay_status,orderid))
        self.conn.commit()
        print("Payment Sucessful")

    def insert_review(self,orderid,review,review_sta):
        self.cur.execute("UPDATE LOG SET review=?  WHERE orderid=?",(review,orderid))
        self.cur.execute("UPDATE LOG SET review_sta=? WHERE orderid=?",(review_sta,orderid))
        self.conn.commit()



    def show_log(self):
        d=self.cur.execute("SELECT * FROM LOG").fetchall()
        df = pd.DataFrame(columns=['Order-Id','Paid','Mp','Is','Sv','Pb','Bo','Tea','Poori','Review','Rev_type'],data=d)
        ndf=pd.DataFrame()
        pdf=pd.DataFrame()
        ndf=df[df['Rev_type']=='0'][['Order-Id','Review']]
        pdf=df[df['Rev_type']=='1'][['Order-Id','Review']]
        pos=self.cur.execute("SELECT COUNT(*) FROM LOG WHERE review_sta = 1").fetchall()
        neg=self.cur.execute("SELECT COUNT(*) FROM LOG WHERE review_sta = 0").fetchall()
        return(df,ndf,pdf,neg[0][0],pos[0][0])
