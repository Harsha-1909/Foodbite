# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'signin.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 206)
        self.gmailid = QtWidgets.QLineEdit(Dialog)
        self.gmailid.setGeometry(QtCore.QRect(110, 60, 271, 41))
        self.gmailid.setObjectName("gmailid")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(20, 60, 101, 41))
        self.label_3.setObjectName("label_3")
        self.signinbutton = QtWidgets.QPushButton(Dialog)
        self.signinbutton.setGeometry(QtCore.QRect(260, 120, 121, 41))
        self.signinbutton.setObjectName("signinbutton")
        self.signupbutton = QtWidgets.QPushButton(Dialog)
        self.signupbutton.setGeometry(QtCore.QRect(110, 120, 131, 41))
        self.signupbutton.setObjectName("signupbutton")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.gmailid.setPlaceholderText(_translate("Dialog", "Enter Your Gmail-ID"))
        self.label_3.setText(_translate("Dialog", "Gmail-Id"))
        self.signinbutton.setText(_translate("Dialog", "Sign In"))
        self.signupbutton.setText(_translate("Dialog", "Sign Up"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
