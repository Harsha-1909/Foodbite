# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'signup.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(494, 233)
        self.registerbutton = QtWidgets.QPushButton(Dialog)
        self.registerbutton.setGeometry(QtCore.QRect(290, 170, 121, 41))
        self.registerbutton.setObjectName("registerbutton")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(50, 110, 101, 41))
        self.label.setObjectName("label")
        self.gmailid = QtWidgets.QLineEdit(Dialog)
        self.gmailid.setGeometry(QtCore.QRect(140, 110, 271, 41))
        self.gmailid.setObjectName("gmailid")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(50, 50, 91, 41))
        self.label_2.setObjectName("label_2")
        self.name = QtWidgets.QLineEdit(Dialog)
        self.name.setGeometry(QtCore.QRect(140, 50, 271, 41))
        self.name.setObjectName("name")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.registerbutton.setText(_translate("Dialog", "Register"))
        self.label.setText(_translate("Dialog", "Gmail-Id"))
        self.gmailid.setPlaceholderText(_translate("Dialog", "Enter Your Gmail-ID"))
        self.label_2.setText(_translate("Dialog", "Name"))
        self.name.setPlaceholderText(_translate("Dialog", "Enter Your Name"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
