from main import *
from register import *
from Cred import *
from Qrcode import Ui_Dialog as Ui_Qrcode
from status import Ui_Dialog as Ui_status
from signin import Ui_Dialog as Ui_Signin
from signup import Ui_Dialog as Ui_Signup

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from easygui import *
import math, random
import smtplib
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
####
login_true=[0]
#### NLP part ########
ps=PorterStemmer()
ds=pd.read_csv('Restaurant_Reviews.tsv',delimiter='\t',quoting=3)
corpus=[]

#cleaning text
def clean(s):
    l=[]
    s=re.sub('[^a-zA-Z]',' ',s)
    s=s.lower()
    if 'not' in s:
       l.append('not')
    s=[ps.stem(x) for x in s.split() if x not in stopwords.words('english')]
    s.extend(l)
    s=' '.join(s)
    return s

for i in range(1000):
    rev=ds.iloc[:,0][i]
    corpus.append(clean(rev))

from sklearn.feature_extraction.text import CountVectorizer
cv=CountVectorizer()
X=cv.fit_transform(corpus).toarray()
y=ds.iloc[:,1].values

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)

#logistic regression perfomance 36+16
from sklearn.linear_model import LogisticRegression
classifier=LogisticRegression()
classifier.fit(X_train,y_train)

def inp():
    s=input('Enter your restaurant food experience: ')
    rev=str(s)
    new_rev=[]
    new_rev.append(clean(s))
    x_var=cv.transform(new_rev).toarray()
    y_var=classifier.predict(x_var)
    if y_var:
        register_database.insert_review(buffer_orderid[0],rev,1)
        print('\nThanks for giving your review\nvisit us again :)\n')
        print("Payment Processing\n")
    else:
        register_database.insert_review(buffer_orderid[0],rev,0)
        print('\nSorry for your experience\nWe will try to improve our food thanks for giving feedback\n')
        ##mail to owner
        sub='Order-Id :'+buffer_orderid[0];
        b0='Ordered Items'
        b1=','.join(buffer_ordered_items)
        b2=''
        b3='Customer Review :'
        b4=rev;
        b5=''
        b7=''
        b8='Team Foodbite'
        print("Payment Starting\n")
        send_food_info(sub,b0,b1,b2,b3,b4,b5,b7,b8,buffer_mailid[0])


def generateOrderId() :
    digits = "0123456789"
    orderid= ""
    for i in range(6) :
        orderid += digits[math.floor(random.random() * 10)]
    #to check orderid with database for unique
    det=register_database.order_search(orderid)
    while(det!=False):
        orderid= ""
        for i in range(6) :
            orderid += digits[math.floor(random.random() * 10)]
        #to check orderid with database for unique
        det=register_database.order_search(orderid)
    return orderid

def generateOTP(s,to) :
    digits = "0123456789"
    OTP = ""
    for i in range(6) :
        OTP += digits[math.floor(random.random() * 10)]
    sub=s
    b1='Dear Owner,'
    b2=OTP+' is your one time password(OTP).'
    b3='Please enter the OTP to proceed.'
    b4='Thank you,'
    b5='Team Foodbite'
    s_otp()
    send_otp(sub,b1,b2,b3,b4,b5,to)
    text = "Enter the OTP Sent To The  Gmail :"+to
    title = "OTP Portal"
    default_password = ""
    output = passwordbox(text, title, default_password)
    user_otp =str(output)
    return [OTP,user_otp]

def s_otp():
    pop=QtWidgets.QMessageBox()
    pop.setWindowTitle('OTP Generating')
    pop.setText('Press ok to get OTP\nWe are trying to send the OTP\nThis might take upto 1 minute depending on Network connectivity')
    pop.setIcon(QtWidgets.QMessageBox.Information)
    pop.exec_()


def send_food_info(sub,b0,b1,b2,b3,b4,b5,b7,b8,to):
    mail=smtplib.SMTP_SSL("smtp.gmail.com",465)
    mail.login('foodanalysis39@gmail.com','nlp@1909')
    msg= f'Subject: {sub}\n\n{b0}\n{b1}\n{b2}\n{b3}\n{b4}\n{b5}\n{b7}\n{b8}'
    mail.sendmail('foodanalysis39@gmail.com',str(to),msg)
    mail.close()

def send_otp(sub,b1,b2,b3,b4,b5,to):
    mail=smtplib.SMTP_SSL("smtp.gmail.com",465)
    mail.login('foodanalysis39@gmail.com','nlp@1909')
    msg= f'Subject: {sub}\n\n{b1}\n{b2}\n{b3}\n{b4}\n{b5}'
    mail.sendmail('foodanalysis39@gmail.com',str(to),msg)
    mail.close()


buffer_orderid=list();
buffer_ordered_items=list();
buffer_mailid=list();

getitem=['Misal Pav   ','Idly Sambhar','Sambhar Vada','Pav Bhaji   ','Bread Omlet ','Tea Biscuit ','poori       ']
getcost=[30,15,30,25,30,20,20]

#Register class object
register_database=Register("order.db")
login_database=Cred("login.db")

#status class
class status(QDialog,Ui_status):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.submit.clicked.connect(self.sub)

    def sub(self):
        if(self.paid.isChecked()):
            fill_pop=QtWidgets.QMessageBox()
            fill_pop.setWindowTitle('Payment Confirmed.')
            fill_pop.setText('Thank You Visit Us Again.')
            fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            fill_pop.exec_()
            print(buffer_orderid[0])
            register_database.update_pay_status(buffer_orderid[0],1)
            self.close()
        if(self.notpaid.isChecked()):
            print('Payment Failed\n\n')
            self.close()

#upi class
class showupi(QDialog,Ui_Qrcode):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        popbill=QtWidgets.QMessageBox()
        popbill.setWindowTitle('Scan QR Code')
        popbill.setText('Use Google pay / Paytm / phonePe / Any BHMI upi app to scan the QR code.')
        popbill.setIcon(QtWidgets.QMessageBox.Information)
        popbill.show()
        popbill.exec_()
        self.setupUi(self)
        self.backbutton.clicked.connect(self.close)
        self.verifypayment.clicked.connect(self.check)

    def check(self):
        print("\nPayment Processing\n")
        stobj=status()
        stobj.exec_()
        self.close()

#Sign up call
class Signup(QDialog,Ui_Signup):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.registerbutton.clicked.connect(self.reg)

    def reg(self):
        lst=re.findall('\S+@gmail.com',self.gmailid.text())
        if(len(self.name.text())==0 or len(self.gmailid.text())==0):
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Signup')
            err_pop.setText('Please Fill all fields')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()
        elif(len(lst)==0):
            self.f_pop=QtWidgets.QMessageBox()
            self.f_pop.setWindowTitle('Invalid Gmail')
            self.f_pop.setText('Please Enter Valid Gmail Id')
            self.f_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.f_pop.exec_()
        elif(login_database.cred_search(self.gmailid.text())==False):
            otp=generateOTP('OTP For Sign-Up',self.gmailid.text())
            if(otp[0]==otp[1]):
                login_database.add(self.name.text(),self.gmailid.text())
                err_pop=QtWidgets.QMessageBox()
                err_pop.setWindowTitle('Sign Up')
                err_pop.setText('Sucessfully Created Account')
                err_pop.setIcon(QtWidgets.QMessageBox.Information)
                err_pop.show()
                err_pop.exec_()
                self.close()
            else:
                err_pop=QtWidgets.QMessageBox()
                err_pop.setWindowTitle('OTP')
                err_pop.setText('Wrong OTP Entered')
                err_pop.setIcon(QtWidgets.QMessageBox.Warning)
                err_pop.show()
                err_pop.exec_()
        else:
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Sign-Up')
            err_pop.setText('Mail Id Already Exists')
            err_pop.setIcon(QtWidgets.QMessageBox.Information)
            err_pop.show()
            err_pop.exec_()




#Sign IN call
class Signin(QDialog,Ui_Signin):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.signinbutton.clicked.connect(self.check)
        self.signupbutton.clicked.connect(self.generatesignup)

    def check(self):
        buffer_mailid.clear()

        login=login_database.cred_search(self.gmailid.text())
        if(login):
            otp=generateOTP('OTP For Sign-In',login[0][1])
            if(otp[0]==otp[1]):
                buffer_mailid.append(login[0][1])
                login_true.append(1)
                self.close()
                err_pop=QtWidgets.QMessageBox()
                err_pop.setWindowTitle('Sign In')
                err_pop.setText('Sucessfully Signed In')
                err_pop.setIcon(QtWidgets.QMessageBox.Information)
                err_pop.show()
                err_pop.exec_()

                return 1
            else:
                err_pop=QtWidgets.QMessageBox()
                err_pop.setWindowTitle('OTP')
                err_pop.setText('Wrong OTP Entered')
                err_pop.setIcon(QtWidgets.QMessageBox.Warning)
                err_pop.show()
                err_pop.exec_()
        else:
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Sign-In')
            err_pop.setText('Gmail ID Is not registered use signup')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()


    def generatesignup(self):
        Sign_up=Signup()
        Sign_up.exec_()



#serivces/main window class call
class MainWindow(QMainWindow,Ui_MainWindow):
    def __init__(self,parent=None):
        QMainWindow.__init__(self,parent)
        self.checkcred()
        self.setupUi(self)
        self.clearbutton.clicked.connect(self.clear)
        self.orderfoodbutton.clicked.connect(self.order)
        self.paybutton.clicked.connect(self.pay)
        self.summarybutton.clicked.connect(self.Summary)
        self.logoutbutton.clicked.connect(self.logout)

    def checkcred(self):
        signin_obj=Signin()
        signin_obj.exec_()


    def order(self):
        if(len(login_true)==1):
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Login!')
            err_pop.setText('Not Logged in')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()
            self.close()
            return 0
        orderid=generateOrderId()
        q1=0
        q2=0
        q3=0
        q4=0
        q5=0
        q6=0
        q7=0
        if(self.misalpavbox.isChecked()):
            q1=self.qmisalpav.value()
        if(self.idlysambharbox.isChecked()):
            q2=self.qidlysambhar.value()
        if(self.sambharvadabox.isChecked()):
            q3=self.qsambharvada.value()
        if(self.pavbhajibox.isChecked()):
            q4=self.qpavbhaji.value()
        if(self.breadomletbox.isChecked()):
            q5=self.qbreadomlet.value()
        if(self.teabiscuitbox.isChecked()):
            q6=self.qteabiscuit.value()
        if(self.pooribox.isChecked()):
            q7=self.qpoori.value()
        quantity=q1+q2+q3+q4+q5+q6+q7
        # print(quantity)
        if(quantity!=0):
            register_database.add(orderid,0,q1,q2,q3,q4,q5,q6,q7,' ',' ')
            print('Order-ID :',orderid)

        else:
            fill_pop=QtWidgets.QMessageBox()
            fill_pop.setWindowTitle('Order Invoice')
            fill_pop.setText('Please Choose Food Items')
            fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            fill_pop.exec_()

        self.clear()

    def pay(self):
        if(len(login_true)==1):
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Login!')
            err_pop.setText('Not Logged in')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()
            self.close()
            return 0
        orderid = enterbox(msg='Please Enter Your Order-Id', title='Invoice', strip=True)
        buffer_orderid.clear()
        buffer_ordered_items.clear()
        buffer_orderid.append(orderid)
        data=register_database.order_search(orderid)
        if(data):
            print('Database : ',data[0])
            if(data[0][1]=='0'):

                #For Customer BILL
                BILL=0
                print('\n                 ********************BILL***********************\n')
                print('ORDER-ID :'+data[0][0])
                print()
                for i in range(2,len(data[0])-2):
                    if(data[0][i]!='0'):
                        buffer_ordered_items.append(getitem[i-2])
                        BILL=BILL+int(data[0][i])*getcost[i-2]
                        print(getitem[i-2],' :',data[0][i],'    Cost :',int(data[0][i])*getcost[i-2])
                print('\n\nTotal Bill :',BILL)

                #FOR Taling  REVIEW From Customer
                msg = "We’d love to hear your feedback!"
                title = "Please Conform"
                if ccbox(msg, title):     # show a Continue/Cancel dialog
                    inp()  # user chose Continue
                else:  # user chose Cancel
                    pass
                obj=showupi()
                obj.exec_()
            else:
                fill_pop=QtWidgets.QMessageBox()
                fill_pop.setWindowTitle('Payment Invoice')
                fill_pop.setText('You Already Paid Money for This Order.')
                fill_pop.setIcon(QtWidgets.QMessageBox.Information)
                fill_pop.exec_()
        else:
            fill_pop=QtWidgets.QMessageBox()
            fill_pop.setWindowTitle('Order-ID')
            fill_pop.setText('Please Enter Correct Order Id')
            fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            fill_pop.exec_()


    def clear(self):
        if(len(login_true)==1):
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Login!')
            err_pop.setText('Not Logged in')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()
            self.close()
            return 0
        self.misalpavbox.setChecked(False)
        self.idlysambharbox.setChecked(False)
        self.sambharvadabox.setChecked(False)
        self.pavbhajibox.setChecked(False)
        self.breadomletbox.setChecked(False)
        self.teabiscuitbox.setChecked(False)
        self.pooribox.setChecked(False)
        self.qmisalpav.setValue(0)
        self.qidlysambhar.setValue(0)
        self.qsambharvada.setValue(0)
        self.qpavbhaji.setValue(0)
        self.qbreadomlet.setValue(0)
        self.qteabiscuit.setValue(0)
        self.qpoori.setValue(0)

    def Summary(self):
        if(len(login_true)==1):
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Login!')
            err_pop.setText('Not Logged in')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()
            self.close()
            return 0
        otp=generateOTP('OTP For Summary Details',buffer_mailid[0])
        if(otp[0]==otp[1]):
            summary=register_database.show_log()
            print('\n\n       **************************Summary********************************\n')
            print('Dear owner,\nTotal Orders :',summary[0].shape[0], '\nTotal Postive Reviews :',summary[4],'\nTotal Negative Reviews :',summary[3],'\n\n',summary[0])
            print('\n\nNegative Reviews\n\n',summary[1])
            print('\n\nPositive Reviews\n\n',summary[2],'\n\n')
            b0='Total Orders : '+str(summary[0].shape[0])+'\n'
            b1='Positive Reviews : '+str(summary[4])+'\n'
            b2='Negative Reviews : '+str(summary[3])+'\n\n\n'
            b3=summary[0]
            b4='\n\nNegative Reviews\n'
            b5=summary[1]
            b7='\n\nPositive Reviews\n'
            b8=str(summary[2])+'\n\nTeam Foodbite'
            send_food_info('Restaurant Order Survey',b0,b1,b2,b3,b4,b5,b7,b8,buffer_mailid[0])
        else:
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('OTP')
            err_pop.setText('Wrong OTP Entered')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()

    def logout(self):
        if(len(login_true)==1):
            err_pop=QtWidgets.QMessageBox()
            err_pop.setWindowTitle('Login!')
            err_pop.setText('Not Logged in')
            err_pop.setIcon(QtWidgets.QMessageBox.Warning)
            err_pop.show()
            err_pop.exec_()
            self.close()
            return 0
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText("Confirm Logout?")
        msg.setWindowTitle("Logout")
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        #msg.buttonClicked.connect(self.msgbtn)
        msg.show()
        retval=msg.exec_()
        if(retval==4194304):
            pass
        else:
            self.close()

    def msgbtn(self):
        print("Button pressed is:",self.text())





if __name__=="__main__":
    #to create application
    app=QApplication(sys.argv)
    #main window object
    w=MainWindow()
    w.show()
    sys.exit(app.exec_())
