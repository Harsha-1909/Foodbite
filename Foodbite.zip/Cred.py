import sqlite3


class Cred:
    def __init__(self,db):
        self.conn=sqlite3.connect(db)
        self.cur=self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS LOGIN(name Text,mailid Text)")
        self.conn.commit()

    def add(self,name,mailid):
        self.cur.execute("INSERT INTO LOGIN VALUES (?,?)",(name,mailid,))
        self.conn.commit()

    def cred_search(self,gmailid):
        row=self.cur.execute("SELECT * FROM LOGIN WHERE mailid=?",(gmailid,)).fetchall()
        if not row:
            return False
        else:
            return row
