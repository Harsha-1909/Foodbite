# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(945, 814)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(290, 0, 391, 91))
        self.label.setObjectName("label")
        self.misalpavbox = QtWidgets.QCheckBox(self.centralwidget)
        self.misalpavbox.setGeometry(QtCore.QRect(20, 100, 181, 61))
        self.misalpavbox.setObjectName("misalpavbox")
        self.idlysambharbox = QtWidgets.QCheckBox(self.centralwidget)
        self.idlysambharbox.setGeometry(QtCore.QRect(20, 190, 181, 71))
        self.idlysambharbox.setObjectName("idlysambharbox")
        self.sambharvadabox = QtWidgets.QCheckBox(self.centralwidget)
        self.sambharvadabox.setGeometry(QtCore.QRect(20, 300, 201, 71))
        self.sambharvadabox.setObjectName("sambharvadabox")
        self.pavbhajibox = QtWidgets.QCheckBox(self.centralwidget)
        self.pavbhajibox.setGeometry(QtCore.QRect(20, 390, 211, 71))
        self.pavbhajibox.setObjectName("pavbhajibox")
        self.breadomletbox = QtWidgets.QCheckBox(self.centralwidget)
        self.breadomletbox.setGeometry(QtCore.QRect(20, 480, 181, 101))
        self.breadomletbox.setObjectName("breadomletbox")
        self.teabiscuitbox = QtWidgets.QCheckBox(self.centralwidget)
        self.teabiscuitbox.setGeometry(QtCore.QRect(20, 600, 191, 61))
        self.teabiscuitbox.setObjectName("teabiscuitbox")
        self.pooribox = QtWidgets.QCheckBox(self.centralwidget)
        self.pooribox.setGeometry(QtCore.QRect(390, 90, 141, 61))
        self.pooribox.setObjectName("pooribox")
        self.orderfoodbutton = QtWidgets.QPushButton(self.centralwidget)
        self.orderfoodbutton.setGeometry(QtCore.QRect(260, 700, 121, 41))
        self.orderfoodbutton.setObjectName("orderfoodbutton")
        self.Price_Display = QtWidgets.QTextBrowser(self.centralwidget)
        self.Price_Display.setEnabled(False)
        self.Price_Display.setGeometry(QtCore.QRect(400, 290, 451, 281))
        self.Price_Display.setReadOnly(False)
        self.Price_Display.setObjectName("Price_Display")
        self.paybutton = QtWidgets.QPushButton(self.centralwidget)
        self.paybutton.setGeometry(QtCore.QRect(490, 700, 121, 41))
        self.paybutton.setObjectName("paybutton")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(520, 200, 211, 81))
        self.label_2.setObjectName("label_2")
        self.clearbutton = QtWidgets.QPushButton(self.centralwidget)
        self.clearbutton.setGeometry(QtCore.QRect(20, 700, 121, 41))
        self.clearbutton.setObjectName("clearbutton")
        self.qmisalpav = QtWidgets.QSpinBox(self.centralwidget)
        self.qmisalpav.setGeometry(QtCore.QRect(220, 110, 71, 41))
        self.qmisalpav.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qmisalpav.setSpecialValueText("")
        self.qmisalpav.setAccelerated(True)
        self.qmisalpav.setMaximum(30)
        self.qmisalpav.setObjectName("qmisalpav")
        self.qidlysambhar = QtWidgets.QSpinBox(self.centralwidget)
        self.qidlysambhar.setGeometry(QtCore.QRect(220, 210, 71, 41))
        self.qidlysambhar.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qidlysambhar.setSpecialValueText("")
        self.qidlysambhar.setAccelerated(True)
        self.qidlysambhar.setMaximum(30)
        self.qidlysambhar.setObjectName("qidlysambhar")
        self.qsambharvada = QtWidgets.QSpinBox(self.centralwidget)
        self.qsambharvada.setGeometry(QtCore.QRect(220, 310, 71, 41))
        self.qsambharvada.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qsambharvada.setSpecialValueText("")
        self.qsambharvada.setAccelerated(True)
        self.qsambharvada.setMaximum(30)
        self.qsambharvada.setObjectName("qsambharvada")
        self.qpavbhaji = QtWidgets.QSpinBox(self.centralwidget)
        self.qpavbhaji.setGeometry(QtCore.QRect(220, 410, 71, 41))
        self.qpavbhaji.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qpavbhaji.setSpecialValueText("")
        self.qpavbhaji.setAccelerated(True)
        self.qpavbhaji.setMaximum(30)
        self.qpavbhaji.setObjectName("qpavbhaji")
        self.qbreadomlet = QtWidgets.QSpinBox(self.centralwidget)
        self.qbreadomlet.setGeometry(QtCore.QRect(220, 510, 71, 41))
        self.qbreadomlet.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qbreadomlet.setSpecialValueText("")
        self.qbreadomlet.setAccelerated(True)
        self.qbreadomlet.setMaximum(30)
        self.qbreadomlet.setObjectName("qbreadomlet")
        self.qpoori = QtWidgets.QSpinBox(self.centralwidget)
        self.qpoori.setGeometry(QtCore.QRect(580, 100, 71, 41))
        self.qpoori.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qpoori.setSpecialValueText("")
        self.qpoori.setAccelerated(True)
        self.qpoori.setMaximum(30)
        self.qpoori.setObjectName("qpoori")
        self.qteabiscuit = QtWidgets.QSpinBox(self.centralwidget)
        self.qteabiscuit.setGeometry(QtCore.QRect(220, 610, 71, 41))
        self.qteabiscuit.setButtonSymbols(QtWidgets.QAbstractSpinBox.PlusMinus)
        self.qteabiscuit.setSpecialValueText("")
        self.qteabiscuit.setAccelerated(True)
        self.qteabiscuit.setMaximum(30)
        self.qteabiscuit.setObjectName("qteabiscuit")
        self.summarybutton = QtWidgets.QPushButton(self.centralwidget)
        self.summarybutton.setGeometry(QtCore.QRect(730, 700, 121, 41))
        self.summarybutton.setObjectName("summarybutton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 945, 18))
        self.menubar.setObjectName("menubar")
        self.menuHome = QtWidgets.QMenu(self.menubar)
        self.menuHome.setObjectName("menuHome")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menubar.addAction(self.menuHome.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Hot And Fresh</span></p></body></html>"))
        self.misalpavbox.setText(_translate("MainWindow", "Misal pav"))
        self.idlysambharbox.setText(_translate("MainWindow", "Idly Sambhar"))
        self.sambharvadabox.setText(_translate("MainWindow", "Sambhar Vada"))
        self.pavbhajibox.setText(_translate("MainWindow", "Pav Bhaji"))
        self.breadomletbox.setText(_translate("MainWindow", "Bread Omlet"))
        self.teabiscuitbox.setText(_translate("MainWindow", "Tea Biscuit"))
        self.pooribox.setText(_translate("MainWindow", "Poori"))
        self.orderfoodbutton.setText(_translate("MainWindow", "Order Food"))
        self.Price_Display.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\';\">    </span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Misal Pav               30 rs per piece</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Idly Sambhar          15 rs per piece</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Sambhar Vada        30 rs per piece</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Pav Bhaji               25 rs per piece</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Bread Omlet           30 rs per piece</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Tea Biscuit             20 rs per piece</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:12pt;\">Poori                     20 rs per piece</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:12pt;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:12pt;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:12pt;\"><br /></p></body></html>"))
        self.paybutton.setText(_translate("MainWindow", "Pay"))
        self.label_2.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Prices</span></p></body></html>"))
        self.clearbutton.setText(_translate("MainWindow", "Clear"))
        self.summarybutton.setText(_translate("MainWindow", "Summary"))
        self.menuHome.setTitle(_translate("MainWindow", "Food"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
